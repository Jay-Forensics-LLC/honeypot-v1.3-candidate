# Grok review entry point

Start with `docs/VERIFICATION_HANDOFF_2026-09-28.md`, then review `docker-compose.yml`, `configs/nftables/hp-guard.nft.in`, `scripts/firewall.py`, `scripts/pcap.py`, `scripts/healthcheck.py`, `scripts/readiness.py`, and the systemd units.

The current known blocker is Docker embedded DNS resolution from the decoy containers. Direct TCP egress is blocked, but DNS resolution was observed and must be remediated before Internet exposure.

This archive excludes live `.env`, secrets, logs, state, artifacts, and PCAP evidence by design.
