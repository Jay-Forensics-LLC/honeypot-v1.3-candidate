# Live evidence summary — 2026-09-28

This is a concise reconstruction of the terminal evidence produced during live bring-up. It is not a raw forensic export from the laptop.

## Baseline and runtime

- Host: Lenovo IdeaPad Slim 3 15ABR8, AMD Ryzen 7 5825U.
- Docker Engine: 29.1.3.
- Docker Compose: 2.40.3.
- Runtime services: Cowrie, OpenCanary, Suricata, Loki, Alloy, Grafana, incidentd.
- All seven containers reached `running/healthy`.
- Decoy and Grafana published host ports remained loopback-only during validation.
- `hp_guard` was active as an `inet` nftables table and was not persisted to host boot configuration.

## Acceptance / readiness

Observed PASS results after source fixes:

- Cowrie localhost SSH banner + session log.
- OpenCanary structured FTP authentication event.
- Suricata config syntax.
- Suricata EVE presence.
- PCAP ring rotation test.
- Artifact SHA-256 discovery.
- Incident report generation.
- Loki normalized-log query.
- Authenticated Grafana datasource query.
- Backup creation and safe verification.
- Isolated namespace firewall containment.
- Isolated namespace firewall rollback.
- Container and health live check.
- Source log checks (event-driven logic for Cowrie/OpenCanary; freshness for Suricata).

Final health state before explicit live-egress testing:

- severity: LOW
- problems: []
- pcap_running: true
- clock synchronized: true
- log forwarding: true
- Suricata kernel drops: 0

## PCAP evidence

Continuous dumpcap was observed running as:

`dumpcap -q -g -i br-hp-cowrie -i br-hp-canary -s 0 -b filesize:100000 -b files:1000 -b duration:300 -w /var/lib/honeypot/captures/ring.pcapng`

A production ring segment inspected with `capinfos` reported:

- file type: pcapng
- two interfaces
- interface #0: `br-hp-cowrie`, 6 packets
- interface #1: `br-hp-canary`, 6 packets

A controlled `tshark -i any` capture while generating localhost Cowrie SSH and OpenCanary FTP traffic showed:

- Cowrie traffic between 172.29.40.1 and 172.29.40.2 on TCP/2222.
- OpenCanary traffic between 172.29.41.1 and 172.29.41.2 on TCP/2121.

Incidentd was live-verified with `/var/lib/honeypot/captures -> /hp/captures` and successfully read a current pcapng file. The first four bytes were `0a0d0d0a`, the pcapng section-header magic.

## Live egress containment

From both Cowrie and OpenCanary containers:

- Attempted connection to protected LAN target `10.0.0.1:80`: did not connect.
- Attempted connection to public target `1.1.1.1:443`: did not connect.
- `hp_guard` protected-network drop counter increased from 0 to 4 packets / 240 bytes.
- `hp_guard` general egress drop counter increased from 0 to 4 packets / 240 bytes.

This is direct evidence that the bridge-scoped nftables guard blocked the tested TCP egress paths.

## OPEN: Docker embedded DNS

Both decoys successfully resolved `example.com` to `104.20.23.154` through Docker's embedded resolver. OpenCanary `/etc/resolv.conf` showed `nameserver 127.0.0.11` with host resolver forwarding. A direct attempt to overwrite `/etc/resolv.conf` was not viable because the decoy containers are intentionally minimal/read-only.

This remains an unresolved egress/covert-channel concern. Internet exposure has not been approved and should not occur until DNS is deliberately disabled or constrained and re-tested.
